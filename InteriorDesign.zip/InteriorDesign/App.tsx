import React, {useState} from 'react';
import {ArViewerView} from 'react-native-ar-viewer';

import {SafeAreaView, View, Text} from 'react-native';
import RNF from 'react-native-fs';

function App() {
  const [count, setC] = useState(0);
  // let stool = require('./assets/Stool.glb');
  // console.log(stool);

  return (
    <ArViewerView
      style={{flex: 1}}
      model={
        'https://github.com/KhronosGroup/glTF-Sample-Models/raw/main/2.0/LightsPunctualLamp/glTF-Binary/LightsPunctualLamp.glb'
      }
      lightEstimation
      manageDepth
      allowRotate
      allowScale
      allowTranslate
      onStarted={() => console.log('started')}
      onEnded={() => console.log('ended')}
      onModelPlaced={() => {
        console.log('model displayedd');
      }}
      onModelRemoved={() => console.log('model not visible anymore')}
      planeOrientation="both"
    />
  );
}

export default App;
